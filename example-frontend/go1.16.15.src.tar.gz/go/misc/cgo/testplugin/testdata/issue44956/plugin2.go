// Copyright 2021 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package main

import "testplugin/issue44956/base"

func F() *map[int]int { return base.X }

func main() {}
